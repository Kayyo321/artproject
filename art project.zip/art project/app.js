const fs = require('fs')

module.exports = artproject

function artproject() {

    const art = fs.readFileSync(`${__dirname}/artProject.txt`)
    fs.writeFileSync(`${process.cwd()}/artProject.txt`,art)

    let foo = 'Art Project'
    console.log(`Successfully installed ${foo}! this is prototype 0.0.1`)

}

artproject()
